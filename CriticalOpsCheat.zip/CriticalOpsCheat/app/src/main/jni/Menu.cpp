#include "Menu.h"
#include "Drawing.h"
#include "Memory.h"

MiscConfig Menu::miscConfig;
bool Menu::menuOpen = true;

namespace Menu {
    
    void Initialize() {
        // ImGui initialization happens in the hook
    }
    
    void Render() {
        if (!menuOpen) return;
        
        ImGui::SetNextWindowSize(ImVec2(500, 600), ImGuiCond_FirstUseEver);
        ImGui::Begin("Critical Ops - 0x8hooks", &menuOpen, ImGuiWindowFlags_NoCollapse);
        
        // ============ VISUAL TAB ============
        if (ImGui::BeginTabBar("MainTabs")) {
            
            if (ImGui::BeginTabItem("Visuals")) {
                ImGui::Text("ESP Settings");
                ImGui::Separator();
                
                ImGui::Checkbox("ESP Enabled", &ESP::config.enabled);
                ImGui::Checkbox("ESP Box 2D", &ESP::config.box2D);
                ImGui::Checkbox("ESP Box 3D", &ESP::config.box3D);
                ImGui::Checkbox("ESP Lines", &ESP::config.lines);
                ImGui::Checkbox("ESP Health Bar", &ESP::config.healthBar);
                ImGui::Checkbox("ESP Bones (Skeleton)", &ESP::config.bones);
                ImGui::Checkbox("ESP Names", &ESP::config.name);
                ImGui::Checkbox("Visible Only", &ESP::config.visibleOnly);
                
                ImGui::Separator();
                ImGui::Text("ESP Colors");
                ImGui::ColorEdit4("Visible Color", ESP::config.visibleColor);
                ImGui::ColorEdit4("Invisible Color", ESP::config.invisibleColor);
                ImGui::ColorEdit4("Team Color", ESP::config.teamColor);
                ImGui::ColorEdit4("Name Color", ESP::config.nameColor);
                
                ImGui::Separator();
                ImGui::Text("Chams Settings");
                ImGui::Checkbox("Chams Enabled", &Chams::config.enabled);
                ImGui::Checkbox("Rainbow Chams", &Chams::config.rainbow);
                
                const char* chamsColors[] = { "Blue", "Red", "Green" };
                ImGui::Combo("Chams Color", &Chams::config.activeColor, chamsColors, 3);
                
                if (!Chams::config.rainbow) {
                    ImGui::ColorEdit4("Blue Chams", Chams::config.colorBlue);
                    ImGui::ColorEdit4("Red Chams", Chams::config.colorRed);
                    ImGui::ColorEdit4("Green Chams", Chams::config.colorGreen);
                }
                
                ImGui::EndTabItem();
            }
            
            // ============ RAGEBOT TAB ============
            if (ImGui::BeginTabItem("Ragebot")) {
                ImGui::Text("Aimbot Settings");
                ImGui::Separator();
                
                ImGui::Checkbox("Aimbot Enabled", &Aimbot::config.aimbotEnabled);
                ImGui::SameLine();
                ImGui::Checkbox("Firing Check", &Aimbot::config.firingCheck);
                ImGui::Checkbox("Visibility Check", &Aimbot::config.visibilityCheck);
                
                ImGui::Separator();
                ImGui::Text("Aim Target");
                const char* aimTargets[] = { "Head", "Body", "Legs" };
                int currentTarget = (int)Aimbot::config.aimAt;
                if (ImGui::Combo("Aim At", &currentTarget, aimTargets, 3)) {
                    Aimbot::config.aimAt = (AimTarget)currentTarget;
                }
                
                ImGui::SliderFloat("Smoothness", &Aimbot::config.smoothness, 0.0f, 20.0f, "%.1f");
                ImGui::SliderFloat("Aim FOV", &Aimbot::config.aimFOV, 0.0f, 90.0f, "%.1f");
                
                ImGui::Separator();
                ImGui::Text("Hitbox Configs");
                ImGui::SliderFloat("Head Hitbox", &Aimbot::config.hitboxHead, 0.5f, 5.0f, "%.1f");
                ImGui::SliderFloat("Body Hitbox", &Aimbot::config.hitboxBody, 0.5f, 5.0f, "%.1f");
                ImGui::SliderFloat("Legs Hitbox", &Aimbot::config.hitboxLegs, 0.5f, 5.0f, "%.1f");
                
                ImGui::EndTabItem();
            }
            
            // ============ MISCELLANEOUS TAB ============
            if (ImGui::BeginTabItem("Misc")) {
                ImGui::Text("Miscellaneous Settings");
                ImGui::Separator();
                
                ImGui::Checkbox("Team Radar", &miscConfig.teamRadar);
                ImGui::Checkbox("Crouch Shoot", &miscConfig.crouchShoot);
                ImGui::Checkbox("No Duck", &miscConfig.noDuck);
                ImGui::Checkbox("No Recoil", &miscConfig.noRecoil);
                ImGui::Checkbox("Shoot Through Walls", &miscConfig.shootThroughWalls);
                
                ImGui::EndTabItem();
            }
            
            // ============ SKIN CHANGER TAB ============
            if (ImGui::BeginTabItem("Skin Changer")) {
                ImGui::Text("Skin Changer Settings");
                ImGui::Separator();
                
                ImGui::Checkbox("Skin Changer Enabled", &SkinChanger::config.enabled);
                
                ImGui::Separator();
                ImGui::Text("Knife Changer");
                const char* knives[] = { "Default", "Karambit", "M9 Bayonet", "Flip Knife", 
                                          "Butterfly", "Huntsman", "Falchion", "Bowie" };
                ImGui::Combo("Knife Model", &SkinChanger::config.knifeIndex, knives, 8);
                
                ImGui::Separator();
                ImGui::Text("Weapon Skins");
                const char* skins[] = { "Default", "Dragon Lore", "Asiimov", "Kill Confirmed", 
                                         "Fade", "Crimson Web", "Night", "Doppler" };
                ImGui::Combo("Primary Skin", &SkinChanger::config.primarySkin, skins, 8);
                ImGui::Combo("Secondary Skin", &SkinChanger::config.secondarySkin, skins, 8);
                
                ImGui::Separator();
                ImGui::Text("Gloves Changer");
                const char* gloves[] = { "Default", "Driver Gloves", "Hand Wraps", "Moto Gloves", 
                                          "Specialist", "Sport Gloves", "Bloodhound" };
                ImGui::Combo("Gloves Model", &SkinChanger::config.glovesIndex, gloves, 7);
                
                ImGui::EndTabItem();
            }
            
            ImGui::EndTabBar();
        }
        
        ImGui::Text("\nmade by 0x8hooks");
        ImGui::Text("https://discord.gg/Avc5KSFRd2");
        ImGui::Text("Menu Toggle: Volume Down button");
        
        ImGui::End();
    }
    
    void Toggle() {
        menuOpen = !menuOpen;
    }
}