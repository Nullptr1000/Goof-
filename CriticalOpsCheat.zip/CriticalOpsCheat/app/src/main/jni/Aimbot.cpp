#include "Aimbot.h"
#include "Drawing.h"

RagebotConfig Aimbot::config;

namespace Aimbot {
    
    Vector3 GetTargetPosition(const Game::PlayerData& pd, AimTarget target) {
        switch (target) {
            case AimTarget::HEAD:
                return pd.headPosition;
            case AimTarget::BODY:
                return {
                    (pd.position.x + pd.headPosition.x) / 2.0f,
                    (pd.position.y + pd.headPosition.y) / 2.0f,
                    (pd.position.z + pd.headPosition.z) / 2.0f
                };
            case AimTarget::LEGS:
                return {
                    pd.position.x,
                    pd.position.y,
                    pd.position.z + (pd.colliderHeight * 0.15f) // feet area
                };
            default:
                return pd.headPosition;
        }
    }
    
    void Run() {
        if (!config.aimbotEnabled) return;
        
        int screenW = Drawing::GetScreenWidth();
        int screenH = Drawing::GetScreenHeight();
        
        auto cam = Game::GetCamera();
        uintptr_t localPlayer = Game::GetLocalPlayer();
        if (!localPlayer) return;
        
        int localTeam = Memory::Read<int>(localPlayer + Offsets::Player::Team);
        Vector3 localPos = Memory::Read<Vector3>(localPlayer + Offsets::Player::Position);
        Vector3 localAngles = Memory::Read<Vector3>(localPlayer + Offsets::Player::ViewAngles);
        
        // Firing check - only aim when player is shooting
        if (config.firingCheck) {
            // Check if player is firing (weapon animation state or input)
            // This depends on game-specific flags
        }
        
        auto entities = Game::GetEntityList();
        
        float bestFOV = config.aimFOV;
        Vector3 bestAngles = {0, 0, 0};
        bool hasTarget = false;
        
        for (auto entity : entities) {
            if (entity == localPlayer) continue;
            
            auto pd = Game::ReadPlayerData(entity);
            if (!pd.isAlive || pd.health <= 0) continue;
            if (pd.team == localTeam) continue; // Skip teammates
            
            // Visibility check
            if (config.visibilityCheck && !pd.isVisible) continue;
            
            // Get aim position based on config
            Vector3 targetPos = GetTargetPosition(pd, config.aimAt);
            
            // Calculate angles to target
            Vector3 aimAngles = Math::CalcAngles(localPos, targetPos);
            
            // Calculate FOV difference
            float fov = Math::GetFOV(localAngles, aimAngles);
            
            if (fov < bestFOV) {
                bestFOV = fov;
                bestAngles = aimAngles;
                hasTarget = true;
            }
        }
        
        if (hasTarget) {
            // Apply smoothness
            float smoothFactor = 1.0f / (config.smoothness + 1.0f);
            
            Vector3 currentAngles = Memory::Read<Vector3>(localPlayer + Offsets::Player::ViewAngles);
            
            Vector3 delta = bestAngles - currentAngles;
            
            // Normalize
            if (delta.x > 180) delta.x -= 360;
            if (delta.x < -180) delta.x += 360;
            if (delta.y > 180) delta.y -= 360;
            if (delta.y < -180) delta.y += 360;
            
            // Apply smoothing
            Vector3 newAngles;
            newAngles.x = currentAngles.x + delta.x * smoothFactor;
            newAngles.y = currentAngles.y + delta.y * smoothFactor;
            newAngles.z = 0;
            
            // Write angles to player
            Memory::Write<Vector3>(localPlayer + Offsets::Player::ViewAngles, newAngles);
        }
    }
}