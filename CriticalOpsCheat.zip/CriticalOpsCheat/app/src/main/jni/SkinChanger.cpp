#include "SkinChanger.h"

SkinChangerConfig SkinChanger::config;

namespace SkinChanger {
    
    // Weapon ID mappings
    const int weaponIDs[] = {
        0,  // Default
        1,  // Deagle
        2,  // M4
        3,  // AK-47
        4,  // AWP
        5,  // Shotgun
        6,  // SMG
        7   // Pistol
    };
    
    // Skin ID mappings per weapon
    const int skinIDs[] = {
        0,   // Default
        100, // Dragon Lore
        200, // Asiimov
        300, // Kill Confirmed
        400, // Fade
        500, // Crimson Web
        600, // Night
        700  // Doppler
    };
    
    // Knife model ID mappings
    const int knifeModelIDs[] = {
        0,   // Default
        10,  // Karambit
        20,  // M9 Bayonet
        30,  // Flip Knife
        40,  // Butterfly
        50,  // Huntsman
        60,  // Falchion
        70   // Bowie
    };
    
    // Glove model ID mappings
    const int gloveModelIDs[] = {
        0,   // Default
        100, // Driver Gloves
        200, // Hand Wraps
        300, // Moto Gloves
        400, // Specialist
        500, // Sport Gloves
        600  // Bloodhound
    };
    
    void Apply() {
        if (!config.enabled) return;
        
        uintptr_t localPlayer = Game::GetLocalPlayer();
        if (!localPlayer) return;
        
        // Get inventory manager
        uintptr_t inventory = Memory::Read<uintptr_t>(localPlayer + 0x2F8);
        if (!inventory) return;
        
        // Change knife
        if (config.knifeIndex > 0) {
            uintptr_t knifeSlot = Memory::Read<uintptr_t>(inventory + Inventory::KnifeSkins);
            if (knifeSlot) {
                Memory::Write<int>(knifeSlot + Inventory::SkinID, knifeModelIDs[config.knifeIndex]);
            }
        }
        
        // Change weapon skins
        if (config.primarySkin > 0) {
            uintptr_t weaponSkins = Memory::Read<uintptr_t>(inventory + Inventory::WeaponSkins);
            if (weaponSkins) {
                // Loop through weapon slots and apply skin
                for (int i = 0; i < 10; i++) {
                    uintptr_t weaponSlot = Memory::Read<uintptr_t>(weaponSkins + i * sizeof(uintptr_t));
                    if (weaponSlot) {
                        int weaponType = Memory::Read<int>(weaponSlot + 0x8);
                        // Apply based on weapon type
                        if (weaponType >= 1 && weaponType <= 3) { // Primary weapons
                            Memory::Write<int>(weaponSlot + Inventory::SkinID, skinIDs[config.primarySkin]);
                            Memory::Write<float>(weaponSlot + Inventory::Wear, 0.001f); // Minimal wear
                        }
                    }
                }
            }
        }
        
        // Change gloves
        if (config.glovesIndex > 0) {
            uintptr_t gloveSlot = Memory::Read<uintptr_t>(inventory + Inventory::GloveSkins);
            if (gloveSlot) {
                Memory::Write<int>(gloveSlot + Inventory::SkinID, gloveModelIDs[config.glovesIndex]);
            }
        }
    }
    
    void Restore() {
        // Restore original values if needed
        // Store originals in Apply() and restore here
    }
}