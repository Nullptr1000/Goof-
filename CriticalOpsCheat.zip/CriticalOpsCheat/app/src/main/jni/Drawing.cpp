#include "Drawing.h"
#include <cstdio>
#include <cstring>
#include <vector>

static int screenWidth = 1920;
static int screenHeight = 1080;

static GLuint lineShader = 0;
static GLuint fillShader = 0;
static bool shadersCompiled = false;

namespace Drawing {

    int GetScreenWidth() { return screenWidth; }
    int GetScreenHeight() { return screenHeight; }
    void UpdateScreenSize(int w, int h) { screenWidth = w; screenHeight = h; }

    // Compile a simple GL shader from source
    GLuint CompileShader(const char* vertSrc, const char* fragSrc) {
        GLuint vs = glCreateShader(GL_VERTEX_SHADER);
        glShaderSource(vs, 1, &vertSrc, NULL);
        glCompileShader(vs);

        GLuint fs = glCreateShader(GL_FRAGMENT_SHADER);
        glShaderSource(fs, 1, &fragSrc, NULL);
        glCompileShader(fs);

        GLuint prog = glCreateProgram();
        glAttachShader(prog, vs);
        glAttachShader(prog, fs);
        glLinkProgram(prog);

        glDeleteShader(vs);
        glDeleteShader(fs);
        return prog;
    }

    void CompileShaders() {
        if (shadersCompiled) return;

        const char* vertBasic = R"(
            attribute vec2 aPos;
            attribute vec4 aColor;
            varying vec4 vColor;
            uniform mat4 uProj;
            void main() {
                gl_Position = uProj * vec4(aPos, 0.0, 1.0);
                vColor = aColor;
            }
        )";

        const char* fragBasic = R"(
            precision mediump float;
            varying vec4 vColor;
            void main() {
                gl_FragColor = vColor;
            }
        )";

        lineShader = CompileShader(vertBasic, fragBasic);
        fillShader = CompileShader(vertBasic, fragBasic);
        shadersCompiled = true;
    }

    void SetupOrtho() {
        glMatrixMode(GL_PROJECTION);
        glPushMatrix();
        glLoadIdentity();
        glOrtho(0, screenWidth, screenHeight, 0, -1, 1);
        glMatrixMode(GL_MODELVIEW);
        glPushMatrix();
        glLoadIdentity();
        glDisable(GL_DEPTH_TEST);
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    }

    void RestoreGL() {
        glEnable(GL_DEPTH_TEST);
        glDisable(GL_BLEND);
        glMatrixMode(GL_PROJECTION);
        glPopMatrix();
        glMatrixMode(GL_MODELVIEW);
        glPopMatrix();
    }

    void DrawLine(float x1, float y1, float x2, float y2, const Color& color, float thickness) {
        SetupOrtho();
        
        GLfloat vertices[] = { x1, y1, x2, y2 };
        glVertexPointer(2, GL_FLOAT, 0, vertices);
        glEnableClientState(GL_VERTEX_ARRAY);
        
        glColor4f(color.r, color.g, color.b, color.a);
        glLineWidth(thickness);
        glDrawArrays(GL_LINES, 0, 2);
        
        glDisableClientState(GL_VERTEX_ARRAY);
        RestoreGL();
    }

    void DrawRect(float x, float y, float w, float h, const Color& color, float thickness) {
        SetupOrtho();
        
        GLfloat vertices[] = {
            x, y,     x+w, y,
            x+w, y,   x+w, y+h,
            x+w, y+h, x, y+h,
            x, y+h,   x, y
        };
        
        glVertexPointer(2, GL_FLOAT, 0, vertices);
        glEnableClientState(GL_VERTEX_ARRAY);
        
        glColor4f(color.r, color.g, color.b, color.a);
        glLineWidth(thickness);
        glDrawArrays(GL_LINES, 0, 8);
        
        glDisableClientState(GL_VERTEX_ARRAY);
        RestoreGL();
    }

    void DrawFillRect(float x, float y, float w, float h, const Color& color) {
        SetupOrtho();
        
        GLfloat vertices[] = {
            x, y,     x+w, y,
            x+w, y+h,
            x, y,     x+w, y+h,
            x, y+h
        };
        
        glVertexPointer(2, GL_FLOAT, 0, vertices);
        glEnableClientState(GL_VERTEX_ARRAY);
        
        glColor4f(color.r, color.g, color.b, color.a);
        glDrawArrays(GL_TRIANGLES, 0, 6);
        
        glDisableClientState(GL_VERTEX_ARRAY);
        RestoreGL();
    }

    void DrawCircle(float cx, float cy, float radius, const Color& color, int segments) {
        SetupOrtho();
        
        std::vector<GLfloat> vertices;
        for (int i = 0; i < segments; i++) {
            float angle1 = 2.0f * M_PI * i / segments;
            float angle2 = 2.0f * M_PI * (i + 1) / segments;
            
            vertices.push_back(cx + cos(angle1) * radius);
            vertices.push_back(cy + sin(angle1) * radius);
            vertices.push_back(cx + cos(angle2) * radius);
            vertices.push_back(cy + sin(angle2) * radius);
        }
        
        glVertexPointer(2, GL_FLOAT, 0, vertices.data());
        glEnableClientState(GL_VERTEX_ARRAY);
        
        glColor4f(color.r, color.g, color.b, color.a);
        glDrawArrays(GL_LINES, 0, vertices.size() / 2);
        
        glDisableClientState(GL_VERTEX_ARRAY);
        RestoreGL();
    }

    void DrawText(const char* text, float x, float y, const Color& color, float scale) {
        if (!text || !text[0]) return;
        
        SetupOrtho();
        
        // Simple bitmap text rendering using GL lines
        glColor4f(color.r, color.g, color.b, color.a);
        
        float curX = x;
        float charSpacing = 10.0f * scale;
        float charHeight = 12.0f * scale;
        
        for (const char* c = text; *c; c++) {
            if (*c == ' ') {
                curX += charSpacing;
                continue;
            }
            
            // Draw simple character representation
            // A real implementation would use a font atlas/bitmap
            GLfloat vertices[] = {
                curX, y,
                curX + charSpacing * 0.8f, y,
                curX + charSpacing * 0.8f, y + charHeight,
                curX, y + charHeight,
                curX, y
            };
            
            glVertexPointer(2, GL_FLOAT, 0, vertices);
            glEnableClientState(GL_VERTEX_ARRAY);
            glDrawArrays(GL_LINE_STRIP, 0, 5);
            glDisableClientState(GL_VERTEX_ARRAY);
            
            curX += charSpacing;
        }
        
        RestoreGL();
    }
}