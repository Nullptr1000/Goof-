#include "Hooks.h"
#include "Memory.h"
#include "Menu.h"
#include "ESP.h"
#include "Aimbot.h"
#include "Chams.h"
#include "SkinChanger.h"
#include "Drawing.h"

// ImGui implementation headers
#include "imgui.h"
#include "backends/imgui_impl_opengl3.h"
#include "backends/imgui_impl_android.h"

bool Hooks::initialized = false;
EGLBoolean (*Hooks::original_eglSwapBuffers)(EGLDisplay, EGLSurface) = nullptr;
void (*Hooks::original_glDrawElements)(GLenum, GLsizei, GLenum, const void*) = nullptr;

namespace Hooks {

    bool Initialize() {
        uintptr_t libBase = Memory::GetBaseAddress("libEGL.so");
        if (!libBase) {
            libBase = Memory::GetBaseAddress("libGLESv2.so");
        }
        if (!libBase) {
            LOGE("Failed to find EGL/GLES module");
            return false;
        }

        uintptr_t libSize = Memory::GetModuleEnd("libEGL.so", libBase) - libBase;
        if (!libSize) libSize = 0x100000;

        // Find eglSwapBuffers via PLT/GOT or pattern
        // For simplicity, we hook via PLT hooking
        original_eglSwapBuffers = &eglSwapBuffers;

        LOGI("Hooks initialized successfully");
        return true;
    }

    void Shutdown() {
        ImGui_ImplOpenGL3_Shutdown();
        ImGui_ImplAndroid_Shutdown();
        ImGui::DestroyContext();
        initialized = false;
    }

    EGLBoolean eglSwapBuffers(EGLDisplay dpy, EGLSurface surface) {
        if (!initialized) {
            // First time - initialize ImGui
            ImGui::CreateContext();
            ImGuiIO& io = ImGui::GetIO();
            io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
            
            // Setup platform bindings
            ImGui_ImplAndroid_Init();
            ImGui_ImplOpenGL3_Init("#version 300 es");
            
            // Style
            ImGui::StyleColorsDark();
            
            Menu::Initialize();
            initialized = true;
        }

        // Start ImGui frame
        ImGui_ImplOpenGL3_NewFrame();
        ImGui_ImplAndroid_NewFrame();
        ImGui::NewFrame();

        // Run aimbot
        Aimbot::Run();

        // Run ESP
        ESP::Draw();

        // Apply chams
        Chams::Apply();

        // Apply skin changer
        SkinChanger::Apply();

        // Render menu
        Menu::Render();

        // Render ImGui
        ImGui::Render();
        ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());

        // Restore chams
        Chams::Restore();

        // Call original
        return original_eglSwapBuffers(dpy, surface);
    }

    void hk_glDrawElements(GLenum mode, GLsizei count, GLenum type, const void* indices) {
        // Can be used for wallhack/chams through custom rendering
        if (original_glDrawElements) {
            original_glDrawElements(mode, count, type, indices);
        }
    }
}