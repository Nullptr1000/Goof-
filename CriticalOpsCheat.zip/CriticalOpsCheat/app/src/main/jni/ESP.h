#pragma once
#include "Offsets.h"
#include "Game.h"
#include "Math.h"

struct ESPConfig {
    bool enabled = true;
    bool box2D = true;
    bool box3D = false;
    bool lines = true;
    bool healthBar = true;
    bool name = true;
    bool bones = false;
    bool visibleOnly = false;
    float boxColor[4] = {1, 1, 1, 1};
    float lineColor[4] = {1, 0, 0, 1};
    float healthColor[4] = {0, 1, 0, 1};
    float nameColor[4] = {1, 1, 0, 1};
    float enemyColor[4] = {1, 0, 0, 1};
    float teamColor[4] = {0, 1, 0, 1};
    float visibleColor[4] = {0, 1, 0, 1};
    float invisibleColor[4] = {1, 0, 0, 1};
    
    // Team check
    int localTeam = -1;
};

namespace ESP {
    
    extern ESPConfig config;
    
    void Draw();
    void DrawBox(const Vector2& top, const Vector2& bottom, const Color& color, float thickness = 2.0f);
    void Draw3DBox(const Vector3& pos, float radius, float height, const Color& color);
    void DrawLine(const Vector2& from, const Vector2& to, const Color& color, float thickness = 1.0f);
    void DrawHealthBar(const Vector2& top, const Vector2& bottom, float health, float maxHealth);
    void DrawName(const Vector2& top, const char* name, const Color& color);
    void DrawBones(const Vector3 bones[19], const Color& color);
}