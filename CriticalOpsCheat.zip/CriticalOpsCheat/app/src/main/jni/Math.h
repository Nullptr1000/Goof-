#pragma once
#include <cmath>
#include "Offsets.h"

namespace Math {
    
    // World to Screen projection using view matrix
    inline bool WorldToScreen(const Vector3& worldPos, Vector2& screenOut, 
                               float* viewMatrix, int screenW, int screenH) {
        // Transform with view-projection matrix
        float w = viewMatrix[3] * worldPos.x + viewMatrix[7] * worldPos.y + 
                  viewMatrix[11] * worldPos.z + viewMatrix[15];
        
        if (w < 0.01f) return false;
        
        float x = viewMatrix[0] * worldPos.x + viewMatrix[4] * worldPos.y + 
                  viewMatrix[8] * worldPos.z + viewMatrix[12];
        float y = viewMatrix[1] * worldPos.x + viewMatrix[5] * worldPos.y + 
                  viewMatrix[9] * worldPos.z + viewMatrix[13];
        
        // Normalize
        float invW = 1.0f / w;
        x *= invW;
        y *= invW;
        
        // Screen coordinates
        screenOut.x = (screenW / 2.0f) + (x * screenW / 2.0f);
        screenOut.y = (screenH / 2.0f) - (y * screenH / 2.0f);
        
        return true;
    }
    
    // Calculate 2D box height from 3D distance
    inline float GetBoxHeight(float distance, float colliderHeight = 1.8f) {
        const float baseHeight = 100.0f;
        const float refDist = 10.0f;
        return (baseHeight * colliderHeight * refDist) / distance;
    }
    
    // Calculate FOV between aim direction and target
    inline float GetFOV(const Vector3& viewAngles, const Vector3& targetAngles) {
        Vector3 delta = targetAngles - viewAngles;
        
        // Normalize angles
        if (delta.x > 180) delta.x -= 360;
        if (delta.x < -180) delta.x += 360;
        if (delta.y > 180) delta.y -= 360;
        if (delta.y < -180) delta.y += 360;
        
        return sqrtf(delta.x * delta.x + delta.y * delta.y);
    }
    
    // Calculate angles to aim at target
    inline Vector3 CalcAngles(const Vector3& src, const Vector3& dst) {
        Vector3 delta = dst - src;
        Vector3 angles;
        
        float dist = sqrtf(delta.x * delta.x + delta.y * delta.y);
        angles.x = atan2f(delta.y, delta.x) * 180.0f / M_PI;   // yaw
        angles.y = -atan2f(delta.z, dist) * 180.0f / M_PI;      // pitch
        angles.z = 0;
        
        return angles;
    }
}