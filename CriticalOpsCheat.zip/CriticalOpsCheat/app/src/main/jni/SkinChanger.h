#pragma once
#include "Offsets.h"
#include "Memory.h"

struct SkinChangerConfig {
    bool enabled = false;
    int knifeIndex = 0;
    int primarySkin = 0;
    int secondarySkin = 0;
    int glovesIndex = 0;
};

namespace SkinChanger {
    
    extern SkinChangerConfig config;
    
    void Apply();
    void Restore();
    
    // Inventory item structure offsets
    namespace Inventory {
        constexpr uint32_t WeaponSkins = 0x28;
        constexpr uint32_t KnifeSkins = 0x30;
        constexpr uint32_t GloveSkins = 0x38;
        constexpr uint32_t SkinID = 0x10;
        constexpr uint32_t Wear = 0x14;
    }
}