#pragma once
#include <cstdint>
#include <cstring>
#include <cmath>

// Critical Ops - Unity IL2CPP Offsets (v1.70.0)
// Use IL2CPPDumper to update these per version

namespace Offsets {
    
    // Module name
    constexpr const char* GAME_MODULE = "libil2cpp.so";
    
    namespace Player {
        // Player object offsets (relative to player instance pointer)
        constexpr uint32_t Health       = 0x88;    // float
        constexpr uint32_t MaxHealth    = 0x8C;    // float  
        constexpr uint32_t Team         = 0x90;    // int32 (0=Coalition, 1=Breach)
        constexpr uint32_t IsAlive      = 0x94;    // bool
        constexpr uint32_t NamePtr      = 0x98;    // Il2CppString*
        constexpr uint32_t Position     = 0xA0;    // Vector3 (x,y,z = 3 floats)
        constexpr uint32_t Rotation     = 0xAC;    // Vector3
        constexpr uint32_t ViewAngles   = 0xB8;    // Vector2 (pitch, yaw)
        constexpr uint32_t IsVisible    = 0xC0;    // bool (raycast check)
        constexpr uint32_t WeaponId     = 0xC4;    // int32
        constexpr uint32_t BoneArray    = 0xD0;    // float[16*numBones]
        constexpr uint32_t HeadOffset   = 0x1A0;   // Vector3
        constexpr uint32_t ColliderSize = 0x1B0;   // Vector2 (radius, height)
        constexpr uint32_t IsBot        = 0x1C0;   // bool
        constexpr uint32_t PlayerFlags  = 0x1C4;   // int32
        constexpr uint32_t CurrentClip  = 0x1C8;   // int32
        constexpr uint32_t ReserveAmmo  = 0x1CC;   // int32
        constexpr uint32_t Armor        = 0x1D0;   // int32
        constexpr uint32_t Helmet       = 0x1D4;   // bool
    }
    
    namespace Camera {
        constexpr uint32_t ViewMatrix   = 0x2C;    // float[16] - view projection matrix
        constexpr uint32_t CameraPos    = 0x6C;    // Vector3
        constexpr uint32_t FOV          = 0x80;    // float
    }
    
    namespace Engine {
        // UWorld -> UGameInstance -> ULocalPlayer -> PlayerController -> PlayerPawn/Camera
        constexpr uint32_t GameInstanceOffset      = 0x18;
        constexpr uint32_t LocalPlayerArrayOffset  = 0x38;
        constexpr uint32_t PlayerControllerOffset  = 0x30;
        constexpr uint32_t PlayerCameraOffset      = 0x2B8;
        constexpr uint32_t PlayerPawnOffset        = 0x2F0;
        constexpr uint32_t ActorArrayOffset        = 0x100;
        constexpr uint32_t ActorCountOffset        = 0x108;
    }

    namespace Signatures {
        // GWorld/UWorld pointer pattern 
        constexpr const char* GWorld = "48 8B 05 ? ? ? ? 48 8B 88 ? ? ? ? 48 85 C9 74 ? 48 8B 49";
        // GUObjectArray
        constexpr const char* GObjects = "48 8B 0D ? ? ? ? 48 8B 04 D1 48 85 C0 74";
        // GNames
        constexpr const char* GNames = "48 8B 05 ? ? ? ? 48 85 C0 75 ? 48 8D 0D";
        // EglSwapBuffers hook
        constexpr const char* SwapBuffers = "FF ?? ?? ?? 00 00 00 00 00"; 
    }
}

// === Structs ===

struct Vector3 {
    float x, y, z;
    Vector3() : x(0), y(0), z(0) {}
    Vector3(float x, float y, float z) : x(x), y(y), z(z) {}
    
    Vector3 operator+(const Vector3& o) const { return {x+o.x, y+o.y, z+o.z}; }
    Vector3 operator-(const Vector3& o) const { return {x-o.x, y-o.y, z-o.z}; }
    Vector3 operator*(float s) const { return {x*s, y*s, z*s}; }
    Vector3 operator/(float s) const { return {x/s, y/s, z/s}; }
    
    float Dot(const Vector3& o) const { return x*o.x + y*o.y + z*o.z; }
    float Length() const { return sqrtf(x*x + y*y + z*z); }
    float Distance(const Vector3& o) const { return (*this - o).Length(); }
    Vector3 Normalize() const { float l = Length(); return l > 0 ? *this / l : Vector3(); }
};

struct Vector2 {
    float x, y;
    Vector2() : x(0), y(0) {}
    Vector2(float x, float y) : x(x), y(y) {}
    Vector2 operator+(const Vector2& o) const { return {x+o.x, y+o.y}; }
    Vector2 operator-(const Vector2& o) const { return {x-o.x, y-o.y}; }
    Vector2 operator*(float s) const { return {x*s, y*s}; }
};

struct Bone {
    Vector3 position;
    float rotation[4]; // quaternion
};

struct Color {
    float r, g, b, a;
    Color() : r(1), g(1), b(1), a(1) {}
    Color(float r, float g, float b, float a = 1) : r(r), g(g), b(b), a(a) {}
    
    static Color Red()    { return {1,0,0,1}; }
    static Color Green()  { return {0,1,0,1}; }
    static Color Blue()   { return {0,0,1,1}; }
    static Color White()  { return {1,1,1,1}; }
    static Color Black()  { return {0,0,0,1}; }
    static Color Yellow() { return {1,1,0,1}; }
    static Color Cyan()   { return {0,1,1,1}; }
    static Color Magenta(){ return {1,0,1,1}; }
    
    uint32_t ToU32() const {
        return (uint32_t)(a * 255) << 24 | (uint32_t)(r * 255) << 16 | 
               (uint32_t)(g * 255) << 8 | (uint32_t)(b * 255);
    }
};

struct ImVec2 {
    float x, y;
    ImVec2() : x(0), y(0) {}
    ImVec2(float x, float y) : x(x), y(y) {}
};

// Bone indices for humanoid skeleton
enum BoneIndex {
    BONE_HIP = 0,
    BONE_SPINE = 1,
    BONE_CHEST = 2,
    BONE_NECK = 3,
    BONE_HEAD = 4,
    BONE_LEFT_SHOULDER = 5,
    BONE_LEFT_ARM = 6,
    BONE_LEFT_FOREARM = 7,
    BONE_LEFT_HAND = 8,
    BONE_RIGHT_SHOULDER = 9,
    BONE_RIGHT_ARM = 10,
    BONE_RIGHT_FOREARM = 11,
    BONE_RIGHT_HAND = 12,
    BONE_LEFT_THIGH = 13,
    BONE_LEFT_LEG = 14,
    BONE_LEFT_FOOT = 15,
    BONE_RIGHT_THIGH = 16,
    BONE_RIGHT_LEG = 17,
    BONE_RIGHT_FOOT = 18,
    BONE_COUNT = 19
};