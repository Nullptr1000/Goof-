#pragma once
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <dlfcn.h>
#include <unistd.h>
#include <sys/mman.h>
#include <android/log.h>

#define LOG_TAG "COPS"
#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)

namespace Memory {
    
    inline uintptr_t GetBaseAddress(const char* moduleName) {
        FILE* fp = fopen("/proc/self/maps", "r");
        if (!fp) return 0;
        
        char line[512];
        uintptr_t base = 0;
        
        while (fgets(line, sizeof(line), fp)) {
            if (strstr(line, moduleName) && strstr(line, "r-xp")) {
                base = strtoul(line, NULL, 16);
                break;
            }
        }
        fclose(fp);
        return base;
    }
    
    inline uintptr_t GetModuleEnd(const char* moduleName, uintptr_t base) {
        FILE* fp = fopen("/proc/self/maps", "r");
        if (!fp) return 0;
        
        char line[512];
        uintptr_t end = 0;
        
        while (fgets(line, sizeof(line), fp)) {
            if (strstr(line, moduleName)) {
                uintptr_t start;
                sscanf(line, "%lx-%lx", &start, &end);
                if (start == base) break;
            }
        }
        fclose(fp);
        return end;
    }
    
    // Pattern scan with mask (x = match, ? = wildcard)
    inline uintptr_t FindPattern(uintptr_t base, uintptr_t size, 
                                  const uint8_t* pattern, const char* mask) {
        size_t maskLen = strlen(mask);
        for (uintptr_t i = 0; i < size - maskLen; i++) {
            bool found = true;
            for (size_t j = 0; j < maskLen; j++) {
                if (mask[j] == 'x' && 
                    ((uint8_t*)base)[i + j] != pattern[j]) {
                    found = false;
                    break;
                }
            }
            if (found) return base + i;
        }
        return 0;
    }
    
    // Pattern scan from IDA-style signature "48 8B 05 ?? ?? ?? ?? 48 8B 88"
    inline uintptr_t FindPatternIDA(uintptr_t base, uintptr_t size, const char* sig) {
        // Parse signature string to bytes and mask
        std::vector<uint8_t> pattern;
        std::string mask;
        
        char tmp[3] = {0};
        for (const char* p = sig; *p; p++) {
            if (*p == ' ') continue;
            if (*p == '?') {
                pattern.push_back(0);
                mask += '?';
                if (*(p+1) == '?') p++;
            } else {
                tmp[0] = *p;
                tmp[1] = *(p+1);
                pattern.push_back((uint8_t)strtoul(tmp, NULL, 16));
                mask += 'x';
                p++;
            }
        }
        
        return FindPattern(base, size, pattern.data(), mask.c_str());
    }
    
    // Read process memory
    template<typename T>
    inline T Read(uintptr_t addr) {
        return *(T*)addr;
    }
    
    // Write process memory
    template<typename T>
    inline void Write(uintptr_t addr, T value) {
        // Unprotect memory page
        uintptr_t pageStart = addr & ~0xFFF;
        mprotect((void*)pageStart, 0x1000, PROT_READ | PROT_WRITE | PROT_EXEC);
        *(T*)addr = value;
    }
    
    // Read pointer chain
    inline uintptr_t ReadPointerChain(uintptr_t base, const std::vector<uint32_t>& offsets) {
        uintptr_t addr = base;
        for (size_t i = 0; i < offsets.size(); i++) {
            if (!addr) return 0;
            if (i == offsets.size() - 1) {
                addr = addr + offsets[i];
            } else {
                addr = *(uintptr_t*)(addr + offsets[i]);
            }
        }
        return addr;
    }
    
    // Get pointer offset relative to module base
    inline uintptr_t GetAbsoluteAddress(uintptr_t moduleBase, uint32_t offset) {
        return moduleBase + offset;
    }
}