#pragma once
#include "imgui.h"
#include "ESP.h"
#include "Aimbot.h"
#include "Chams.h"
#include "SkinChanger.h"

struct MiscConfig {
    bool teamRadar = false;
    bool crouchShoot = false;
    bool noDuck = false;
    bool noRecoil = false;
    bool shootThroughWalls = false;
};

namespace Menu {
    extern MiscConfig miscConfig;
    extern bool menuOpen;
    
    void Initialize();
    void Render();
    void Toggle();
}