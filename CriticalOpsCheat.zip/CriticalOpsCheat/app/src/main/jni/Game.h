#pragma once
#include "Memory.h"
#include "Offsets.h"
#include <vector>

namespace Game {
    
    struct PlayerData {
        uintptr_t address;
        Vector3 position;
        Vector3 headPosition;
        float health;
        float maxHealth;
        int team;
        bool isAlive;
        bool isVisible;
        char name[64];
        int weaponId;
        Vector3 bones[BONE_COUNT];
        bool hasBones;
        float colliderRadius;
        float colliderHeight;
    };
    
    struct CameraData {
        float viewMatrix[16];
        Vector3 position;
        float fov;
    };
    
    // Get the UWorld pointer
    inline uintptr_t GetUWorld() {
        uintptr_t libBase = Memory::GetBaseAddress(Offsets::GAME_MODULE);
        if (!libBase) return 0;
        
        uintptr_t libSize = Memory::GetModuleEnd(Offsets::GAME_MODULE, libBase) - libBase;
        uintptr_t sigAddr = Memory::FindPatternIDA(libBase, libSize, Offsets::Signatures::GWorld);
        
        if (!sigAddr) return 0;
        
        // The pattern is: 48 8B 05 ?? ?? ?? ??  (rip-relative lea)
        // Read the 4-byte displacement at offset 3
        int32_t displacement = *(int32_t*)(sigAddr + 3);
        uintptr_t gworldPtr = sigAddr + 7 + displacement;
        
        return *(uintptr_t*)gworldPtr;
    }
    
    // Get local player pawn
    inline uintptr_t GetLocalPlayer() {
        uintptr_t world = GetUWorld();
        if (!world) return 0;
        
        uintptr_t gameInstance = *(uintptr_t*)(world + Offsets::Engine::GameInstanceOffset);
        if (!gameInstance) return 0;
        
        uintptr_t localPlayers = *(uintptr_t*)(gameInstance + Offsets::Engine::LocalPlayerArrayOffset);
        if (!localPlayers) return 0;
        
        uintptr_t localPlayer = *(uintptr_t*)(localPlayers);
        if (!localPlayer) return 0;
        
        uintptr_t playerController = *(uintptr_t*)(localPlayer + Offsets::Engine::PlayerControllerOffset);
        if (!playerController) return 0;
        
        uintptr_t pawn = *(uintptr_t*)(playerController + Offsets::Engine::PlayerPawnOffset);
        return pawn;
    }
    
    // Get camera data
    inline CameraData GetCamera() {
        CameraData cam = {};
        
        uintptr_t world = GetUWorld();
        if (!world) return cam;
        
        uintptr_t gameInstance = *(uintptr_t*)(world + Offsets::Engine::GameInstanceOffset);
        if (!gameInstance) return cam;
        
        uintptr_t localPlayers = *(uintptr_t*)(gameInstance + Offsets::Engine::LocalPlayerArrayOffset);
        if (!localPlayers) return cam;
        
        uintptr_t localPlayer = *(uintptr_t*)(localPlayers);
        if (!localPlayer) return cam;
        
        uintptr_t playerController = *(uintptr_t*)(localPlayer + Offsets::Engine::PlayerControllerOffset);
        if (!playerController) return cam;
        
        uintptr_t camera = *(uintptr_t*)(playerController + Offsets::Engine::PlayerCameraOffset);
        if (!camera) return cam;
        
        // Read view matrix (4x4 = 16 floats)
        memcpy(cam.viewMatrix, (void*)(camera + Offsets::Camera::ViewMatrix), 16 * sizeof(float));
        cam.position = *(Vector3*)(camera + Offsets::Camera::CameraPos);
        cam.fov = *(float*)(camera + Offsets::Camera::FOV);
        
        return cam;
    }
    
    // Get all entities (players)
    inline std::vector<uintptr_t> GetEntityList() {
        std::vector<uintptr_t> entities;
        
        uintptr_t world = GetUWorld();
        if (!world) return entities;
        
        uintptr_t actorArray = *(uintptr_t*)(world + Offsets::Engine::ActorArrayOffset);
        int actorCount = *(int*)(world + Offsets::Engine::ActorCountOffset);
        
        if (!actorArray || actorCount <= 0 || actorCount > 100) return entities;
        
        for (int i = 0; i < actorCount; i++) {
            uintptr_t actor = *(uintptr_t*)(actorArray + i * sizeof(uintptr_t));
            if (actor) {
                entities.push_back(actor);
            }
        }
        
        return entities;
    }
    
    // Read player data from entity
    inline PlayerData ReadPlayerData(uintptr_t playerAddr) {
        PlayerData pd = {};
        pd.address = playerAddr;
        
        // Read basic data
        pd.health = Memory::Read<float>(playerAddr + Offsets::Player::Health);
        pd.maxHealth = Memory::Read<float>(playerAddr + Offsets::Player::MaxHealth);
        pd.team = Memory::Read<int>(playerAddr + Offsets::Player::Team);
        pd.isAlive = Memory::Read<bool>(playerAddr + Offsets::Player::IsAlive);
        pd.isVisible = Memory::Read<bool>(playerAddr + Offsets::Player::IsVisible);
        pd.position = Memory::Read<Vector3>(playerAddr + Offsets::Player::Position);
        pd.weaponId = Memory::Read<int>(playerAddr + Offsets::Player::WeaponId);
        pd.colliderRadius = Memory::Read<float>(playerAddr + Offsets::Player::ColliderSize);
        pd.colliderHeight = Memory::Read<float>(playerAddr + Offsets::Player::ColliderSize + 4);
        
        // Read name (Il2CppString pointer)
        uintptr_t namePtr = Memory::Read<uintptr_t>(playerAddr + Offsets::Player::NamePtr);
        if (namePtr) {
            // Il2CppString structure: | length (int) | padding | utf16 chars... |
            int32_t strLen = Memory::Read<int32_t>(namePtr + 0x8);
            if (strLen > 0 && strLen < 32) {
                uint16_t* strData = (uint16_t*)(namePtr + 0xC);
                for (int i = 0; i < strLen && i < 63; i++) {
                    pd.name[i] = (char)strData[i];
                }
                pd.name[strLen] = 0;
            }
        }
        
        // Read head position (from head offset)
        pd.headPosition = pd.position;
        Vector3 headOffset = Memory::Read<Vector3>(playerAddr + Offsets::Player::HeadOffset);
        pd.headPosition.z += headOffset.z + 0.5f;
        
        // Read bones
        pd.hasBones = true;
        for (int i = 0; i < BONE_COUNT && i < 19; i++) {
            uintptr_t boneAddr = playerAddr + Offsets::Player::BoneArray + (i * sizeof(float) * 4);
            // Each bone is typically stored as position (3 floats) + some alignment
            pd.bones[i].x = Memory::Read<float>(boneAddr);
            pd.bones[i].y = Memory::Read<float>(boneAddr + 4);
            pd.bones[i].z = Memory::Read<float>(boneAddr + 8);
        }
        
        return pd;
    }
}