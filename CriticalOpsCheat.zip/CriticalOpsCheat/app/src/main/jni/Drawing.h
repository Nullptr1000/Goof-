#pragma once
#include "Offsets.h"
#include <GLES2/gl2.h>

namespace Drawing {

    // Screen info
    int GetScreenWidth();
    int GetScreenHeight();
    void UpdateScreenSize(int w, int h);

    // GL-based drawing primitives
    void DrawLine(float x1, float y1, float x2, float y2, const Color& color, float thickness = 1.0f);
    void DrawRect(float x, float y, float w, float h, const Color& color, float thickness = 1.0f);
    void DrawFillRect(float x, float y, float w, float h, const Color& color);
    void DrawCircle(float cx, float cy, float radius, const Color& color, int segments = 32);
    void DrawText(const char* text, float x, float y, const Color& color, float scale = 0.4f);

    // Internal GL helpers
    void SetupOrtho();
    void RestoreGL();
}