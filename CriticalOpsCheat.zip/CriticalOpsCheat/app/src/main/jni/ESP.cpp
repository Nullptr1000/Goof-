#include "ESP.h"
#include "Drawing.h"
#include "Menu.h"
#include <vector>

ESPConfig ESP::config;

namespace ESP {
    
    void DrawBox(const Vector2& top, const Vector2& bottom, const Color& color, float thickness) {
        float width = (bottom.y - top.y) * 0.5f;
        float x = top.x - width / 2;
        float y = top.y;
        float w = width;
        float h = bottom.y - top.y;
        
        Drawing::DrawRect(x, y, w, 1, color, thickness);                    // top
        Drawing::DrawRect(x, y + h, w, 1, color, thickness);                // bottom
        Drawing::DrawRect(x, y, 1, h, color, thickness);                    // left
        Drawing::DrawRect(x + w, y, 1, h, color, thickness);                // right
    }
    
    void Draw3DBox(const Vector3& pos, float radius, float height, const Color& color) {
        // Get screen dimensions
        int screenW = Drawing::GetScreenWidth();
        int screenH = Drawing::GetScreenHeight();
        
        // Get camera matrix
        auto cam = Game::GetCamera();
        
        // 8 corners of the box
        Vector3 corners[8] = {
            {pos.x - radius, pos.y - radius, pos.z - height/2},
            {pos.x + radius, pos.y - radius, pos.z - height/2},
            {pos.x + radius, pos.y + radius, pos.z - height/2},
            {pos.x - radius, pos.y + radius, pos.z - height/2},
            {pos.x - radius, pos.y - radius, pos.z + height/2},
            {pos.x + radius, pos.y - radius, pos.z + height/2},
            {pos.x + radius, pos.y + radius, pos.z + height/2},
            {pos.x - radius, pos.y + radius, pos.z + height/2}
        };
        
        Vector2 screen[8];
        for (int i = 0; i < 8; i++) {
            if (!Math::WorldToScreen(corners[i], screen[i], cam.viewMatrix, screenW, screenH))
                return;
        }
        
        // Draw bottom square
        Drawing::DrawLine(screen[0].x, screen[0].y, screen[1].x, screen[1].y, color);
        Drawing::DrawLine(screen[1].x, screen[1].y, screen[2].x, screen[2].y, color);
        Drawing::DrawLine(screen[2].x, screen[2].y, screen[3].x, screen[3].y, color);
        Drawing::DrawLine(screen[3].x, screen[3].y, screen[0].x, screen[0].y, color);
        
        // Draw top square
        Drawing::DrawLine(screen[4].x, screen[4].y, screen[5].x, screen[5].y, color);
        Drawing::DrawLine(screen[5].x, screen[5].y, screen[6].x, screen[6].y, color);
        Drawing::DrawLine(screen[6].x, screen[6].y, screen[7].x, screen[7].y, color);
        Drawing::DrawLine(screen[7].x, screen[7].y, screen[4].x, screen[4].y, color);
        
        // Draw vertical lines
        Drawing::DrawLine(screen[0].x, screen[0].y, screen[4].x, screen[4].y, color);
        Drawing::DrawLine(screen[1].x, screen[1].y, screen[5].x, screen[5].y, color);
        Drawing::DrawLine(screen[2].x, screen[2].y, screen[6].x, screen[6].y, color);
        Drawing::DrawLine(screen[3].x, screen[3].y, screen[7].x, screen[7].y, color);
    }
    
    void DrawLine(const Vector2& from, const Vector2& to, const Color& color, float thickness) {
        Drawing::DrawLine(from.x, from.y, to.x, to.y, color);
    }
    
    void DrawHealthBar(const Vector2& top, const Vector2& bottom, float health, float maxHealth) {
        float width = (bottom.y - top.y) * 0.5f;
        float barX = top.x - width / 2 - 6;
        float barY = top.y;
        float barW = 4;
        float barH = bottom.y - top.y;
        
        // Background
        Drawing::DrawFillRect(barX, barY, barW, barH, Color(0, 0, 0, 0.7f));
        
        // Health fill
        float healthPercent = (health / maxHealth);
        if (healthPercent < 0) healthPercent = 0;
        if (healthPercent > 1) healthPercent = 1;
        
        float fillH = barH * healthPercent;
        float fillY = barY + (barH - fillH);
        
        // Color: green > yellow > red based on health
        Color healthColor;
        if (healthPercent > 0.6f)      healthColor = Color(0, 1, 0, 1);
        else if (healthPercent > 0.3f) healthColor = Color(1, 1, 0, 1);
        else                           healthColor = Color(1, 0, 0, 1);
        
        Drawing::DrawFillRect(barX, fillY, barW, fillH, healthColor);
        
        // Border
        Drawing::DrawRect(barX, barY, barW, barH, Color(1, 1, 1, 0.5f), 1);
    }
    
    void DrawName(const Vector2& top, const char* name, const Color& color) {
        float width = 200; // max width for name
        float textX = top.x - width / 2;
        float textY = top.y - 16;
        
        Drawing::DrawText(name, textX, textY, color, 0.4f);
    }
    
    void DrawBones(const Vector3 bones[19], const Color& color) {
        int screenW = Drawing::GetScreenWidth();
        int screenH = Drawing::GetScreenHeight();
        auto cam = Game::GetCamera();
        
        // Bone connections
        const int connections[][2] = {
            {BONE_HIP, BONE_SPINE},
            {BONE_SPINE, BONE_CHEST},
            {BONE_CHEST, BONE_NECK},
            {BONE_NECK, BONE_HEAD},
            {BONE_CHEST, BONE_LEFT_SHOULDER},
            {BONE_LEFT_SHOULDER, BONE_LEFT_ARM},
            {BONE_LEFT_ARM, BONE_LEFT_FOREARM},
            {BONE_LEFT_FOREARM, BONE_LEFT_HAND},
            {BONE_CHEST, BONE_RIGHT_SHOULDER},
            {BONE_RIGHT_SHOULDER, BONE_RIGHT_ARM},
            {BONE_RIGHT_ARM, BONE_RIGHT_FOREARM},
            {BONE_RIGHT_FOREARM, BONE_RIGHT_HAND},
            {BONE_HIP, BONE_LEFT_THIGH},
            {BONE_LEFT_THIGH, BONE_LEFT_LEG},
            {BONE_LEFT_LEG, BONE_LEFT_FOOT},
            {BONE_HIP, BONE_RIGHT_THIGH},
            {BONE_RIGHT_THIGH, BONE_RIGHT_LEG},
            {BONE_RIGHT_LEG, BONE_RIGHT_FOOT}
        };
        
        Vector2 screen1, screen2;
        
        for (int i = 0; i < 18; i++) {
            int idx1 = connections[i][0];
            int idx2 = connections[i][1];
            
            if (Math::WorldToScreen(bones[idx1], screen1, cam.viewMatrix, screenW, screenH) &&
                Math::WorldToScreen(bones[idx2], screen2, cam.viewMatrix, screenW, screenH)) {
                Drawing::DrawLine(screen1.x, screen1.y, screen2.x, screen2.y, color, 1.5f);
            }
        }
    }
    
    void Draw() {
        if (!config.enabled) return;
        
        int screenW = Drawing::GetScreenWidth();
        int screenH = Drawing::GetScreenHeight();
        
        auto cam = Game::GetCamera();
        auto entities = Game::GetEntityList();
        uintptr_t localPlayer = Game::GetLocalPlayer();
        
        if (!localPlayer) return;
        
        // Get local team
        config.localTeam = Memory::Read<int>(localPlayer + Offsets::Player::Team);
        
        for (auto entity : entities) {
            if (entity == localPlayer) continue;
            
            auto pd = Game::ReadPlayerData(entity);
            if (!pd.isAlive || pd.health <= 0) continue;
            if (config.visibleOnly && !pd.isVisible) continue;
            
            // Determine color
            Color drawColor;
            if (pd.team == config.localTeam) {
                drawColor = Color(config.teamColor[0], config.teamColor[1], config.teamColor[2], 1);
                // Skip team if same team
                continue; // uncomment to skip team ESP
            } else {
                if (pd.isVisible) {
                    drawColor = Color(config.visibleColor[0], config.visibleColor[1], config.visibleColor[2], 1);
                } else {
                    drawColor = Color(config.invisibleColor[0], config.invisibleColor[1], config.invisibleColor[2], 1);
                }
            }
            
            // World to screen
            Vector2 screenPos, screenHead;
            if (!Math::WorldToScreen(pd.position, screenPos, cam.viewMatrix, screenW, screenH)) continue;
            if (!Math::WorldToScreen(pd.headPosition, screenHead, cam.viewMatrix, screenW, screenH)) continue;
            
            // Calculate box bounds
            Vector2 boxTop = screenHead;
            Vector2 boxBottom = screenPos;
            
            // ESP Box 2D
            if (config.box2D) {
                DrawBox(boxTop, boxBottom, drawColor);
            }
            
            // ESP Box 3D
            if (config.box3D) {
                Draw3DBox(pd.position, pd.colliderRadius, pd.colliderHeight, drawColor);
            }
            
            // ESP Lines (from bottom of screen to player)
            if (config.lines) {
                Vector2 screenCenter(screenW / 2.0f, screenH);
                DrawLine(screenCenter, screenPos, drawColor);
            }
            
            // ESP Health Bar
            if (config.healthBar) {
                DrawHealthBar(boxTop, boxBottom, pd.health, pd.maxHealth);
            }
            
            // ESP Name
            if (config.name && pd.name[0]) {
                DrawName(boxTop, pd.name, Color(config.nameColor[0], config.nameColor[1], config.nameColor[2], 1));
            }
            
            // ESP Bones
            if (config.bones && pd.hasBones) {
                DrawBones(pd.bones, drawColor);
            }
        }
    }
}