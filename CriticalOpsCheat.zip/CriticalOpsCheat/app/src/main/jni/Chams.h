#pragma once
#include "Offsets.h"
#include <EGL/egl.h>
#include <GLES2/gl2.h>
#include <GLES2/gl2ext.h>

struct ChamsConfig {
    bool enabled = false;
    bool rainbow = false;
    float colorBlue[4] = {0, 0, 1, 0.6f};
    float colorRed[4] = {1, 0, 0, 0.6f};
    float colorGreen[4] = {0, 1, 0, 0.6f};
    int activeColor = 0; // 0=blue, 1=red, 2=green
};

namespace Chams {
    extern ChamsConfig config;
    
    void Apply();
    void Restore();
    
    // GL shader for chams
    extern GLuint chamsShader;
    extern GLuint originalProgram;
    void CompileShaders();
}