#include <jni.h>
#include <android/log.h>
#include <dlfcn.h>
#include <thread>
#include <chrono>
#include <cstring>

#include "Memory.h"
#include "Hooks.h"
#include "Menu.h"
#include "Game.h"

// JNI entry point - called when the library is loaded
extern "C" JNIEXPORT jint JNICALL
JNI_OnLoad(JavaVM* vm, void* reserved) {
    LOGI("Critical Ops Cheat library loaded");

    // Start initialization in a background thread
    std::thread([]() {
        // Wait for the game to fully load
        std::this_thread::sleep_for(std::chrono::seconds(3));

        // Get game module base
        uintptr_t libBase = Memory::GetBaseAddress(Offsets::GAME_MODULE);
        if (!libBase) {
            LOGE("Failed to find game module: %s", Offsets::GAME_MODULE);
            return;
        }
        LOGI("Game module base: 0x%lx", libBase);

        // Initialize hooks
        if (Hooks::Initialize()) {
            LOGI("Hooks installed successfully");
        } else {
            LOGE("Failed to install hooks");
        }

        LOGI("Critical Ops Cheat initialized successfully");
    }).detach();

    return JNI_VERSION_1_6;
}

// Cleanup when library is unloaded
extern "C" JNIEXPORT void JNICALL
JNI_OnUnload(JavaVM* vm, void* reserved) {
    LOGI("Critical Ops Cheat library unloading");
    Hooks::Shutdown();
}

// Volume down key detection for menu toggle
extern "C" JNIEXPORT void JNICALL
Java_com_criticalops_cheat_MainActivity_toggleMenu(JNIEnv* env, jobject thiz) {
    Menu::Toggle();
}