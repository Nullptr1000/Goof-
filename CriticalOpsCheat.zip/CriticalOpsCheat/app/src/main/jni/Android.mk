LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)

LOCAL_MODULE := criticalops_cheat
LOCAL_SRC_FILES := \
    main.cpp \
    ESP.cpp \
    Aimbot.cpp \
    Chams.cpp \
    Menu.cpp \
    SkinChanger.cpp \
    Hooks.cpp \
    Drawing.cpp \
    imgui/imgui.cpp \
    imgui/imgui_draw.cpp \
    imgui/imgui_widgets.cpp \
    imgui/imgui_tables.cpp \
    imgui/backends/imgui_impl_opengl3.cpp \
    imgui/backends/imgui_impl_android.cpp

LOCAL_C_INCLUDES := \
    $(LOCAL_PATH) \
    $(LOCAL_PATH)/imgui \
    $(LOCAL_PATH)/imgui/backends

LOCAL_LDLIBS := -llog -landroid -lEGL -lGLESv2 -lGLESv3
LOCAL_CFLAGS := -std=c++17 -O2 -fvisibility=hidden -fno-rtti -fno-exceptions
LOCAL_CPPFLAGS := -std=c++17 -O2

include $(BUILD_SHARED_LIBRARY)