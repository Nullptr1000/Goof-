#pragma once
#include <EGL/egl.h>
#include <GLES2/gl2.h>

namespace Hooks {
    
    extern bool initialized;
    
    bool Initialize();
    void Shutdown();
    
    // Hooked functions
    EGLBoolean eglSwapBuffers(EGLDisplay dpy, EGLSurface surface);
    void hk_glDrawElements(GLenum mode, GLsizei count, GLenum type, const void* indices);
    
    // Original function pointers
    extern EGLBoolean (*original_eglSwapBuffers)(EGLDisplay, EGLSurface);
    extern void (*original_glDrawElements)(GLenum, GLsizei, GLenum, const void*);
}