#include "Chams.h"
#include <cstdio>

ChamsConfig Chams::config;
GLuint Chams::chamsShader = 0;
GLuint Chams::originalProgram = 0;

namespace Chams {
    
    const char* chamsVertexShader = R"(
        attribute vec4 aPosition;
        attribute vec4 aColor;
        varying vec4 vColor;
        uniform mat4 uMVPMatrix;
        void main() {
            gl_Position = uMVPMatrix * aPosition;
            vColor = aColor;
        }
    )";
    
    const char* chamsFragmentShader = R"(
        precision mediump float;
        varying vec4 vColor;
        uniform vec4 uChamsColor;
        void main() {
            gl_FragColor = uChamsColor;
        }
    )";
    
    void CompileShaders() {
        GLuint vertexShader = glCreateShader(GL_VERTEX_SHADER);
        glShaderSource(vertexShader, 1, &chamsVertexShader, NULL);
        glCompileShader(vertexShader);
        
        GLuint fragmentShader = glCreateShader(GL_FRAGMENT_SHADER);
        glShaderSource(fragmentShader, 1, &chamsFragmentShader, NULL);
        glCompileShader(fragmentShader);
        
        chamsShader = glCreateProgram();
        glAttachShader(chamsShader, vertexShader);
        glAttachShader(chamsShader, fragmentShader);
        glLinkProgram(chamsShader);
        
        glDeleteShader(vertexShader);
        glDeleteShader(fragmentShader);
    }
    
    void Apply() {
        if (!config.enabled) return;
        
        // Get current shader program
        GLint currentProg;
        glGetIntegerv(GL_CURRENT_PROGRAM, &currentProg);
        originalProgram = currentProg;
        
        if (!chamsShader) CompileShaders();
        
        glUseProgram(chamsShader);
        
        // Set chams color
        float color[4];
        if (config.rainbow) {
            static float hue = 0;
            hue += 0.01f;
            if (hue > 360) hue = 0;
            
            // HSV to RGB
            float h = hue / 60.0f;
            int i = (int)h;
            float f = h - i;
            float q = 1.0f - f;
            
            switch (i % 6) {
                case 0: color[0]=1; color[1]=f; color[2]=0; break;
                case 1: color[0]=q; color[1]=1; color[2]=0; break;
                case 2: color[0]=0; color[1]=1; color[2]=f; break;
                case 3: color[0]=0; color[1]=q; color[2]=1; break;
                case 4: color[0]=f; color[1]=0; color[2]=1; break;
                case 5: color[0]=1; color[1]=0; color[2]=q; break;
            }
            color[3] = 0.6f;
        } else {
            switch (config.activeColor) {
                case 0: memcpy(color, config.colorBlue, 16); break;
                case 1: memcpy(color, config.colorRed, 16); break;
                case 2: memcpy(color, config.colorGreen, 16); break;
                default: memcpy(color, config.colorBlue, 16); break;
            }
        }
        
        GLint colorLoc = glGetUniformLocation(chamsShader, "uChamsColor");
        glUniform4f(colorLoc, color[0], color[1], color[2], color[3]);
        
        // Enable depth test override
        glEnable(GL_DEPTH_TEST);
        glDepthFunc(GL_LEQUAL);
        
        // Disable face culling to see through walls
        glDisable(GL_CULL_FACE);
    }
    
    void Restore() {
        if (!config.enabled) return;
        
        if (originalProgram) {
            glUseProgram(originalProgram);
        }
        
        glEnable(GL_CULL_FACE);
        glDepthFunc(GL_LESS);
    }
}