#pragma once
#include "Offsets.h"
#include "Game.h"
#include "Math.h"

enum class AimTarget {
    HEAD = 0,
    BODY,
    LEGS
};

struct RagebotConfig {
    bool aimbotEnabled = true;
    bool firingCheck = true;
    bool visibilityCheck = true;
    AimTarget aimAt = AimTarget::HEAD;
    float smoothness = 5.0f;
    float aimFOV = 15.0f;
    float hitboxHead = 1.0f;
    float hitboxBody = 1.0f;
    float hitboxLegs = 1.0f;
};

namespace Aimbot {
    
    extern RagebotConfig config;
    
    void Run();
    Vector3 GetTargetPosition(const Game::PlayerData& pd, AimTarget target);
}